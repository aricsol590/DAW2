<?php
$cadena="H-O-L-A";
$array=explode("-",$cadena);
foreach ($array as $posicion) {
        echo $posicion;
}
?>