<?php
function suma($a,$b){
    return $a+$b;
}
function resta($a,$b){
    return $a-$b;
}
function mult($a,$b){
    return $a*$b;
}
echo mult(2,2);
echo "\n";
echo suma(2,2);
echo "\n";
echo resta(2,2);
?>